package com.rahmananda.catatankeuangan;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rahmananda.catatankeuangan.model.Keuangan;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class KeuanganAdapter extends RecyclerView.Adapter<KeuanganAdapter.KeuanganViewHolder> {
    Locale localeId = new Locale("in", "ID");
    NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeId);

    private ArrayList<Keuangan> arrayList = new ArrayList<>();

    public void setArrayList(ArrayList<Keuangan> arrayList){
        this.arrayList = arrayList;

    }

    private Activity activity;
    public KeuanganAdapter(Activity activity){
        this.activity = activity;
    }

    @NonNull
    @Override
    public KeuanganAdapter.KeuanganViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_keuangan, parent,false);
        return new KeuanganViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KeuanganAdapter.KeuanganViewHolder holder, int position) {
        holder.tvNominal.setText(formatRupiah.format(arrayList.get(position).getNominal()));
        holder.tvKeterangan.setText(String.valueOf(arrayList.get(position).getKeterangan()));
        holder.tvTanggal.setText(String.valueOf(arrayList.get(position).getTanggal()));

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class KeuanganViewHolder extends RecyclerView.ViewHolder {

        private TextView tvNominal, tvKeterangan, tvTanggal;

        public KeuanganViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNominal = itemView.findViewById(R.id.tv_nominal);
            tvKeterangan = itemView.findViewById(R.id.tv_keterangan);
            tvTanggal = itemView.findViewById(R.id.tv_tanggal);
        }
    }
}
